#ifndef MBED_MOTOR_H
#define MBED_MOTOR_H

#include "mbed.h"

class Motor
{
public:


    Motor(PinName pwm, PinName dir1, PinName dir2);

    float speed(float speed, bool direction);
    float speed(float speed);
    Motor& operator= (float speed);


protected:
    PwmOut _pwm;
    DigitalOut _dir1;
    DigitalOut _dir2;
    bool _direction;


};

#endif
