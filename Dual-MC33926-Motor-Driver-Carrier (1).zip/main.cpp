#include "Motor.h"
#include "mbed.h"

int main(){
    while(1){
        }
    }